<?php 

// Common Start

    function alert($data,$color="danger"){
        return "<p class='alert alert-$color'>$data</p>";
    }

    function runQuery($sql){
        if(mysqli_query(conn(),$sql)){
            return true;
        }
        else{
            die("Query Fail : ".mysqli_error());
        }
    }

    function redirect($l){
        header("location:$l");
    }

// Common End


// Auth Start 

function register(){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if($password == $cpassword){
        $spass = md5($password);
        $spass = sha1($spass);
        $spass = password_hash($spass,PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (name,email,password) VALUES ('$name','$email','$spass')";
        if(runQuery($sql)){
            redirect("login.php");
        }
    }else{
        return alert("Password don't match");
    }
}

function login(){

    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT * FROM users WHERE email='$email'";
    $spass = md5($password);
    $spass = sha1($spass);
    $query = mysqli_query(conn(),$sql);
    $row = mysqli_fetch_assoc($query);

    if(!$row){
        return alert("Incorrect Email or Password");
    }
    else{
        if(!password_verify($spass,$row['password'])){
            return alert("Incorrect Email or Password");
        }
        else{
            session_start();
            $_SESSION['user'] = $row;
            redirect("dashboard.php");
        }
    }
}

// Auth End 