<?php require "core/auth.php"; ?>

<?php include "template/header.php"; ?>

<h1>This is Dashboard Page</h1>

<?php include "template/footer.php"; ?>
